import sys

# Can be removed when Robot Framework 2.8.4 is not supported.
JYTHON = sys.platform.startswith('java')
