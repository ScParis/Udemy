import sys

print("Hello Robotizador!!!")
print("Teste de execução de processo com erro!!!!")
sys.exit("FAIL: Erro proposital!!!")
