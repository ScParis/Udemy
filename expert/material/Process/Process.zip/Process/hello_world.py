import time

print("Hello Robotizador!!!")
print("Fechando em 5 segundos...")
for count in range(5):
    print(count+1)
    time.sleep(1)
